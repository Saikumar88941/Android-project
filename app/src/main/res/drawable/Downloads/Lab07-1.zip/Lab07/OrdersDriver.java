package groceries;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import groceries.Drinks.Milkshakes;

public class OrdersDriver {
    public static void main(String[] args) throws FileNotFoundException {            
        //1. Declare and initialize a scanner object to read from file "input.txt"
        System.out.println("*****************************************************");
        System.out.println("******************** SHOPPING MART ******************");
        System.out.println("*****************************************************");
        while (scan.hasNext()) {
            //2. Declare and initialize an OrderSummary object and name it as orderSum
            //3. Read vegetables name and convert it to Vegetable enum. 
            // Note: You can convert to Vegetables enum here in the main method or you can create a
            // private static method after main method in the same class to convert a 
            // string that is read to Vegetables enum. Do not use switch or if else to convert to enums.
            //4. Read vegetable weight and quantity of the vegetables from the input file.
            //5. Read fruit, drinks, milkshakes, ice-creams, desserts and convert them to enums
            //Please follow same rules as provided above for Vegetables enums.
            //6. Read the day from the given input file.
            //7. Create an Orders object with above attributes and name it as order
            //8. Add order, an Orders object created above to orderSum object which is an orderSummary Class object
            //9. Print the receipt for orders.
        }
    }
}
