import Foundation
import FirebaseFirestoreSwift

struct CategoryModel: Codable {
    var Calories, description, foodImage, ingredients,title : String
}


