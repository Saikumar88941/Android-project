import Foundation
import FirebaseFirestoreSwift

struct OffersModel: Codable {
    var image: String?
}
