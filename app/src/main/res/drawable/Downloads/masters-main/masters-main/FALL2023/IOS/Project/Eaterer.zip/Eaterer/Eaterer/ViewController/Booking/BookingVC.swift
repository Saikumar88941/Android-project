 
import UIKit


var bookingVC : BookingVC!

class BookingVC: UIViewController {

   
    override func viewDidLoad() {
        bookingVC = self
    }
}
