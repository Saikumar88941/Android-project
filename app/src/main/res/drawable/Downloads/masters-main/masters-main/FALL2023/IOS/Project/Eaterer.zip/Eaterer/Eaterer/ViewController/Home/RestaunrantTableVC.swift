
import UIKit

class RestaunrantTableVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
}
