package com.example.PetsDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
//		Owner o1 = new Owner(12, "Pradeep");
//		Owner o2 = new Owner(14, "Ajay");
//		Trainer t1 = new Trainer(1, "trainer1");
//
//		Pet p1 = new Pet(1, "Bablu", o2, t1);// pet is dependent on owner & trainer
//
//		System.out.println(o1.toString());
//
//		System.out.println(p1.toString());
//
//		System.out.println(t1.toString());

		ApplicationContext context = new ClassPathXmlApplicationContext("AppContext.xml");

		Pet p = context.getBean("pet", Pet.class);
		Trainer t = context.getBean("trainer", Trainer.class);
		Owner o = context.getBean("owner", Owner.class);

		System.out.println(p);
		System.out.println(t);
		System.out.println(o);
	}
}
