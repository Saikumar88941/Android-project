package com.example.PetsDemo;

public class Pet {

	private int petID;
	private String petName;
	private Owner owner;
	private Trainer trainer;

	public Pet() {
		owner = new Owner();
		trainer = new Trainer();
	}

//	public Pet(int petID, String petName, Owner owner) {
//		this.petID = petID;
//		this.petName = petName;
//		this.owner = owner;
//	}

	public Pet(int petID, String petName, Owner owner, Trainer trainer) {
		super();
		this.petID = petID;
		this.petName = petName;
		this.owner = owner;
		this.trainer = trainer;
	}

	public int getPetID() {
		return petID;
	}

	public void setPetID(int petID) {
		this.petID = petID;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "Pet [petID=" + petID + ", petName=" + petName + ", owner=" + owner + ", trainer=" + trainer + "]";
	}

}
