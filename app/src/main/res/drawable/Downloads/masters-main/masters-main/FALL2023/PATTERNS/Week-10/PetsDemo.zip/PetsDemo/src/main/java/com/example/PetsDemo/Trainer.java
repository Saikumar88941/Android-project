package com.example.PetsDemo;

public class Trainer {

	private int trainerID;
	private String trainerName;

	public Trainer(int trainerID, String trainerName) {
		super();
		this.trainerID = trainerID;
		this.trainerName = trainerName;
	}

	public Trainer() {

	}

	public int getTrainerID() {
		return trainerID;
	}

	public void setTrainerID(int trainerID) {
		this.trainerID = trainerID;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	@Override
	public String toString() {
		return "Trainer [trainerID=" + trainerID + ", trainerName=" + trainerName + "]";
	}

}
